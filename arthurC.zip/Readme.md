# NetFlox
## TODO
* ~~Vue pour la liste des films~~
  + pagination
  + des boutons toggle pour ajouter au Favoris
* ~~Vue pour la liste des célébrités~~
  + pagination

* ~~Une vue détaillée d'un film avec la liste des participations de célébrités~~
  + un bouton toggle pour ajouter au Favoris

* ~~Une vue détaillée de célébrité avec la liste des participations à des films~~

* Vue pour la liste des favoris de l'utilisateur courant
  + boutons pour supprimer des favoris

* Recherche sur le titre des films
  + réutilisation de la vue liste de films
* Recherche sur le nom et prénom des célébrités
  + réutilisation de la vue liste de célébrités
